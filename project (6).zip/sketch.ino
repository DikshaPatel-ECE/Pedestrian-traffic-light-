// Pin define karo
int greenPin = 8;
int yellowPin = 9;
int redPin = 10;
int buttonPin = 7;

void setup() {
  pinMode(greenPin, OUTPUT);
  pinMode(yellowPin, OUTPUT);
  pinMode(redPin, OUTPUT);
  pinMode(buttonPin, INPUT_PULLUP); // Button ke liye pull-up
}

// Normal traffic: hamesha Green ON
void normalTraffic() {
  digitalWrite(greenPin, HIGH);
  digitalWrite(yellowPin, LOW);
  digitalWrite(redPin, LOW);
}

// Pedestrian crossing sequence
void pedestrianCrossing() {
  // Green OFF immediately
  digitalWrite(greenPin, LOW);

  // 2 sec baad Yellow ON
  delay(2000);
  digitalWrite(yellowPin, HIGH);

  // 5 sec baad Red ON
  delay(5000);
  digitalWrite(yellowPin, LOW);
  digitalWrite(redPin, HIGH);

  // 10 sec baad wapas Green ON
  delay(10000);
  digitalWrite(redPin, LOW);
  digitalWrite(greenPin, HIGH);
}

void loop() {
  // Agar button press hua toh pedestrianCrossing() call hoga
  if (digitalRead(buttonPin) == LOW) {
    pedestrianCrossing();
  } else {
    normalTraffic();
  }
}
